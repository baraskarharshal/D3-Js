import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, OnDestroy } from '@angular/core';
//import { NodeIcons } from './../icons.config';
import './../radarChart.js';
import { withLatestFrom } from 'rxjs/operators';

declare var d3: any;
declare var RadarChart:any;

@Component({
    selector: 'app-visual-tree',
    templateUrl: './visual-tree.component.html',
    styleUrls: ['./visual-tree.component.css']
})
export class VisualTreeComponent implements OnInit, AfterViewInit, OnDestroy {

    /*
        * Here  base class has 'visual' property will be the object 
        * of 'VisualTree' .. see how we have extend the Visual Component
        */

    @ViewChild('visualContainer')
    visualContainer: ElementRef;
    visual: any = { id: "1234567890" };
    chartData: any;    

    constructor() {
        // Initialize chart data
        this.chartData = [
            [
              {axis:"Net income margin",value:0.40},
              {axis:"EBITDA margin",value:0.25},
              {axis:"D/E Ratio",value:0.40},
              {axis:"Adverse News",value:0.30},
              {axis:"New SG Tenders won",value:0.25},
              {axis:"ICR",value:0.40},
              		
            ]
          ];
    }

    ngAfterViewInit() {

        let width = this.visualContainer.nativeElement.offsetWidth,
            height = this.visualContainer.nativeElement.offsetHeight;

        let ele = this.visualContainer.nativeElement;

        d3.selectAll('#explode-' + this.visual.id)
            .on('click', () => {
                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");
                
            });

        d3.selectAll('#explore-' + this.visual.id)
            .on('click', () => {

                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");

            });


        d3.selectAll('#explodeList-' + this.visual.id)
            .on('click', () => {

                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");
                //explodeInList(uriData)
            })
        d3.selectAll('#view360-' + this.visual.id)
            .on('click', () => {
                //instance360View(uriData)
                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");
            })

        d3.selectAll('#recommend-' + this.visual.id)
            .on('click', () => {
                // this.recommendCluster(uriData)
                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");
            })

        let tooltip = d3.select("#menu-" + this.visual.id);

        let tooltipInstance = d3.select("#menuInstance-" + this.visual.id);

        // Create svg
        let svg = d3.selectAll("#graphID-" + this.visual.id).append("svg");
              
		/******************* SET UP ****************************/

        var margin = {top: 100, right: 100, bottom: 100, left: 100};
        width = Math.min(700, window.innerWidth - 10) - margin.left - margin.right,
        height = Math.min(width, window.innerHeight - margin.top - margin.bottom - 20);
                
        
        /******************* DRAW THE CHART ****************************/

        var color = d3.scale.ordinal()
            .range(["#EDC951","#CC333F","#00A0B0"]);
            
        var radarChartOptions = {
          w: width,
          h: height,
          margin: margin,
          maxValue: 0.5,
          levels: 10,
          roundStrokes: false,
          color: color
        };

        //Call function to draw the Radar chart
        RadarChart(".radarChart", this.chartData, radarChartOptions, svg);

       
         
    }// End of ngAfterViewInit

    ngOnInit() {
        this.visual.onResize = () => {
        };
    }

    ngOnDestroy() {
        d3.select(this.visualContainer.nativeElement).remove();
    }


    onEditNode() {
        document
            .querySelector("#menu")
            .setAttribute('style', 'display:none');

        //this.sidebarService.open(ConfigureNodeComponent);
    }

}


//} // End of Component
