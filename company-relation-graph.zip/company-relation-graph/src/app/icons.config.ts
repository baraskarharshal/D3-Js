export const NodeIcons = {

    "Annual Volume": {
        "cluster": "/assets/svg/annualincome/clusters.svg",
        "instance": "/assets/svg/annualincome/instances.svg",
        "class": "/assets/svg/annualincome/class.svg"
    },
    "Cluster": {
        "cluster": "/assets/svg/cluster/clusters.svg",
        "instance": "/assets/svg/cluster/instances.svg",
        "class": "/assets/svg/cluster/class.svg"
    },
    "Cluster Currency": {
        "cluster": "/assets/svg/clustercurrency/clusters.svg",
        "instance": "/assets/svg/clustercurrency/instances.svg",
        "class": "/assets/svg/clustercurrency/class.svg"
    },
    "Conversion Cost": {
        "cluster": "/assets/svg/conversioncost/clusters.svg",
        "instance": "/assets/svg/conversioncost/instances.svg",
        "class": "/assets/svg/conversioncost/class.svg"
    },
    "Country of Use": {
        "cluster": "/assets/svg/countryofuse/clusters.svg",
        "instance": "/assets/svg/countryofuse/instances.svg",
        "class": "/assets/svg/countryofuse/class.svg"
    },
    "Currency": {
        "cluster": "/assets/svg/currency/clusters.svg",
        "instance": "/assets/svg/currency/instances.svg",
        "class": "/assets/svg/currency/class.svg"
    },
    "Equipment Platform": {
        "cluster": "/assets/svg/equipment/clusters.svg",
        "instance": "/assets/svg/equipment/instances.svg",
        "class": "/assets/svg/equipment/class.svg"
    },
    "Tier 1 Supplier": {
        "cluster": "/assets/svg/tier1/clusters.svg",
        "instance": "/assets/svg/tier1/instances.svg",
        "class": "/assets/svg/tier1/class.svg"
    },
    "Tier 2 Supplier": {
        "cluster": "/assets/svg/tier2/clusters.svg",
        "instance": "/assets/svg/tier2/instances.svg",
        "class": "/assets/svg/tier2/class.svg"
    },

    "default": {
        "cluster": "\uf2bd",
        "instance": "\uf2bd",
        "class": "\uf15c"
    }


}