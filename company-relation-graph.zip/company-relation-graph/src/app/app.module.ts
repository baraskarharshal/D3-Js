import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { VisualTreeComponent } from './visual-tree/visual-tree.component';


@NgModule({
  declarations: [
    AppComponent,
    VisualTreeComponent,
    
    
  ],
  imports: [
    BrowserModule,
    
  ],
  
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
