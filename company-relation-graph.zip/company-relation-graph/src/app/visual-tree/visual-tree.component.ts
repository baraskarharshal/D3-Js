import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, OnDestroy } from '@angular/core';
import { NodeIcons } from './../icons.config';
import { withLatestFrom } from 'rxjs/operators';

declare var d3: any;

@Component({
    selector: 'app-visual-tree',
    templateUrl: './visual-tree.component.html',
    styleUrls: ['./visual-tree.component.css']
})
export class VisualTreeComponent implements OnInit, AfterViewInit, OnDestroy {

    /*
        * Here  base class has 'visual' property will be the object 
        * of 'VisualTree' .. see how we have extend the Visual Component
        */

    @ViewChild('visualContainer')
    visualContainer: ElementRef;
    visual: any = { id: "1234567890" };
    formatedDataCopy1: any;
    nodes_data: any;
    relations: any;

    private get_wedge_midpoint: Function;

    constructor() {

        this.nodes_data = [{
            "name": "M",
            "type": "company",
            "text": "Mizuho"
        }, {
            "name": "A",
            "type": "company",
            "text": "Company A"
        }]
    
    
        this.relations = [{
            "name": "C",
            "type": "relation",
            "label": "C",
            "text": "Company A Treasury Ltd $82,202,45"
        }, {
            "name": "H",
            "type": "relation",
            "label": "H",
            "text": "HSBC as trustee for MSO trust $133,313,583"
        }, {
            "name": "O",
            "type": "relation",
            "label": "O",
            "text": "Orcherd turn retail Investment pvt. ltd. $30,947,469"
        }, {
            "name": "H",
            "type": "relation",
            "label": "H",
            "text": "HSBC as trustee for company A com trust $111,144,043"
        }, ]
        
    }

    ngAfterViewInit() {

        // d3 js codes starts here
        let width = this.visualContainer.nativeElement.offsetWidth, //650,//window.innerWidth,
            height = this.visualContainer.nativeElement.offsetHeight;


        d3.selectAll('#explode-' + this.visual.id)
            .on('click', () => {

                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");
                //explode(uriData)
            });

        d3.selectAll('#explore-' + this.visual.id)
            .on('click', () => {

                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");

            });


        d3.selectAll('#explodeList-' + this.visual.id)
            .on('click', () => {

                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");
                //explodeInList(uriData)
            })
        d3.selectAll('#view360-' + this.visual.id)
            .on('click', () => {
                //instance360View(uriData)
                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");
            })

        d3.selectAll('#recommend-' + this.visual.id)
            .on('click', () => {
                // this.recommendCluster(uriData)
                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");
            })

        let tooltip = d3.select("#menu-" + this.visual.id);

        let tooltipInstance = d3.select("#menuInstance-" + this.visual.id);

        // Create svg
        let svg = d3.selectAll("#graphID-" + this.visual.id).append("svg")
            .attr("width", width)
            .attr("height", height);

        /************************** Company relationship graph starts here ***********************/

        var lx1 = width * 0.2,
        ly1 = height * 0.4,
        rx2 = width * 0.65,
        ry2 = height * 0.4;
    var m1 = (lx1 + rx2) / 2,
        m2 = (ly1 + ry2) / 2;
    var odd = 0,
        even = 0;
    var distance = 100;
    var relation_list = [];

    //draw left circle
    svg.append("circle")
        .attr('cx', lx1 + 'px')
        .attr('cy', ly1 + 'px')
        .attr("r", "40")
        .attr("fill", "white")
        .attr("stroke", "rgb(108, 108, 165)")
        .attr('stroke-width', '3');

    // Draw text inside left circle
    svg.append("text")
        .text(this.nodes_data[0].name)
        .attr('fill', 'rgb(108, 108, 165)')
        .attr('font-size', "50")
        .attr('text-anchor', 'middle')
        .attr('x', lx1 + 'px')
        .attr('y', (ly1 + 10) + 'px')
        .attr("opacity", 1);

    // Draw text below left circle
    svg.append("text")
        .text(this.nodes_data[0].text)
        .attr('fill', 'rgb(108, 108, 165)')
        .attr('font-size', "15")
        .attr('font-weight', '900')
        .attr('text-anchor', 'middle')
        .attr('x', lx1 + 'px')
        .attr('y', (ly1 + 60) + 'px')
        .attr("opacity", 1);


    //draw right circle
    svg.append("circle")
        .attr('cx', rx2 + 'px')
        .attr('cy', ry2 + 'px')
        .attr("r", "40")
        .attr("fill", "white")
        .attr("stroke", "rgb(108, 108, 165)")
        .attr('stroke-width', '3');

    // Draw text inside right circle
    svg.append("text")
        .text(this.nodes_data[1].name)
        .attr('fill', 'rgb(108, 108, 165)')
        .attr('font-size', "50")
        .attr('text-anchor', 'middle')
        .attr('x', rx2 + 'px')
        .attr('y', (ry2 + 10) + 'px')
        .attr("opacity", 1);

    // Draw text below right circle
    svg.append("text")
        .text(this.nodes_data[1].text)
        .attr('fill', 'rgb(108, 108, 165)')
        .attr('font-size', "15")
        .attr('font-weight', '900')
        .attr('text-anchor', 'middle')
        .attr('x', rx2 + 'px')
        .attr('y', (ry2 + 60) + 'px')
        .attr("opacity", 1);

    /************************ draw relation nodes *********************************/

    // draw odd numbered nodes upside and even numbered nodes downside

    for (var i = 1; i <= this.relations.length; i++) {
        //console.log(i);
        if (i % 2 == 0) {
            //console.log("even");
            // for even number
            even = even + 1;
            var newM2 = m2 + (even * distance)
            svg.append("circle")
                .attr('cx', m1 + 'px')
                .attr('cy', newM2 + 'px')
                .attr("r", "25")
                .attr("fill", "white")
                .attr("stroke", "rgb(108, 108, 165)")
                .attr('stroke-width', '2');

            // Draw text inside circle
            svg.append("text")
                .text(this.relations[i - 1].label)
                .attr('fill', 'rgb(108, 108, 165)')
                .attr('font-size', "30")
                .attr('text-anchor', 'middle')
                .attr('x', m1 + 'px')
                .attr('y', (newM2 + 10) + 'px')
                .attr("opacity", 1);

            // Draw text below circle
            svg.append("foreignObject")
                .text(this.relations[i - 1].text)
                .attr('fill', 'rgb(108, 108, 165)')
                .attr('color', 'rgb(108, 108, 165)')
                .attr('font-size', "13")
                .attr('font-weight', '900')
                .attr('text-anchor', 'middle')
                .attr("width", "160")
                .attr('x', (m1 - 50) + 'px')
                .attr('y', (newM2 + 25) + 'px')
                .attr("opacity", 1);

            //push coordinates of relation node in array
            relation_list.push({
                'x': m1,
                'y': newM2
            })

        } else {
            // for odd number
            //console.log("odd");
            odd = odd + 1;
            var newM2 = m2 - (odd * distance)
            svg.append("circle")
                .attr('cx', m1 + 'px')
                .attr('cy', newM2 + 'px')
                .attr("r", "25")
                .attr("fill", "white")
                .attr("stroke", "rgb(108, 108, 165)")
                .attr('stroke-width', '2');

            // Draw text inside circle
            svg.append("text")
                .text(this.relations[i - 1].label)
                .attr('fill', 'rgb(108, 108, 165)')
                .attr('font-size', "30")
                .attr('text-anchor', 'middle')
                .attr('x', m1 + 'px')
                .attr('y', (newM2 + 10) + 'px')
                .attr("opacity", 1);


            // Draw text below circle
            svg.append("foreignObject")
                .text(this.relations[i - 1].text)
                .attr('color', 'rgb(108, 108, 165)')
                .attr('font-size', "13")
                .attr('font-weight', '900')
                .attr("width", "160")
                .attr('x', (m1 - 50) + 'px')
                .attr('y', (newM2 + 25) + 'px')
                .attr("opacity", 1);

            //push coordinates of relation node in array
            relation_list.push({
                'x': m1,
                'y': newM2
            })
        }

    } // end of for loop

    //console.log(relation_list)

    /**************************** Draw left wedges **********************************************************/

    for (i = 1; i <= relation_list.length; i++) {
        svg.append("path")
            .attr('d', function() {
                var k, h, l, x1, x2, p1, p2, p3, p4, q1, q2, q3, q4, c1, c2, d1, d2, z1, z2, px1 = 0,
                    px2 = 0,
                    py1 = 0,
                    py2 = 0,
                    y1, y2, m1, m2, angle = Math.PI / 100;

                // Set source and target coordinates for wedge
                x1 = relation_list[i - 1].x; // source x
                y1 = relation_list[i - 1].y; // source y
                x2 = lx1; // target x
                y2 = ly1; // target y

                // Get midpoint of wedge
                var points = get_wedge_midpoint(x1, x2, y1, y2, i, "left");
                z1 = points[0];
                z2 = points[1];

                // Calculate first points for triangular wedge
                l = Math.sqrt((x1 - z1) * (x1 - z1) + (y1 - z2) * (y1 - z2))
                var dy = (z2 - y1);
                var dx = (-z1 + x1);
                k = dy * Math.tan(angle) / 1.5
                h = dx * Math.tan(angle) / 1.5
                p1 = x1 + k
                p2 = x1 - k
                q1 = y1 + h
                q2 = y1 - h

                // Calculate second points for triangular wedge
                l = Math.sqrt((z1 - x2) * (z1 - x2) + (z2 - y2) * (z2 - y2))
                dy = (y2 - z2);
                dx = (-x2 + z1);
                k = dy * Math.tan(angle) / 1.5
                h = dx * Math.tan(angle) / 1.5
                p3 = z1 + k
                p4 = z1 - k
                q3 = z2 + h
                q4 = z2 - h

                return 'M ' + p1 + ' ' + q1 +
                    ' L ' + p2 + ' ' + q2 +
                    'L ' + z1 + ' ' + z2 +
                    'L ' + x2 + ' ' + y2 +
                    'L ' + p3 + ' ' + q3 +
                    'm -4, 0 a 4,4 0 1,0 8,0 a 4,4 0 1,0 -8,0';


            })
            .attr("class", "wedge")
            .attr('stroke', 'rgb(224, 224, 224)')
            .attr('fill', 'rgb(224, 224, 224)')
            .attr('stroke-width', '0.1')
            .attr('opacity', '1');

    } // End of for loop

    /**************************** Draw right wedges **********************************************************/

    for (i = 1; i <= relation_list.length; i++) {
        svg.append("path")
            .attr('d', function() {
                var k, h, l, x1, x2, p1, p2, p3, p4, q1, q2, q3, q4, c1, c2, d1, d2, z1, z2, px1 = 0,
                    px2 = 0,
                    py1 = 0,
                    py2 = 0,
                    y1, y2, m1, m2, angle = Math.PI / 100;

                x1 = relation_list[i - 1].x;
                y1 = relation_list[i - 1].y;
                x2 = rx2;
                y2 = ry2;


                var points = get_wedge_midpoint(x1, x2, y1, y2, i, "right");
                z1 = points[0];
                z2 = points[1];

                // Calculate first points for triangular wedge
                l = Math.sqrt((x1 - z1) * (x1 - z1) + (y1 - z2) * (y1 - z2))
                var dy = (z2 - y1);
                var dx = (-z1 + x1);
                k = dy * Math.tan(angle) / 1.5
                h = dx * Math.tan(angle) / 1.5
                p1 = x1 + k
                p2 = x1 - k
                q1 = y1 + h
                q2 = y1 - h

                // Calculate second points for triangular wedge
                l = Math.sqrt((z1 - x2) * (z1 - x2) + (z2 - y2) * (z2 - y2))
                dy = (y2 - z2);
                dx = (-x2 + z1);
                k = dy * Math.tan(angle) / 1.5
                h = dx * Math.tan(angle) / 1.5
                p3 = z1 + k
                p4 = z1 - k
                q3 = z2 + h
                q4 = z2 - h

                return 'M ' + p1 + ' ' + q1 +
                    ' L ' + p2 + ' ' + q2 +
                    'L ' + z1 + ' ' + z2 +
                    'L ' + x2 + ' ' + y2 +
                    'L ' + p3 + ' ' + q3 +
                    'm -4, 0 a 4,4 0 1,0 8,0 a 4,4 0 1,0 -8,0';


            })
            .attr("class", "wedge")
            .attr('stroke', 'rgb(224, 224, 224)')
            .attr('fill', 'rgb(224, 224, 224)')
            .attr('stroke-width', '0.1')
            .attr('opacity', '1');

    } // End of for loop

    // Move wedges upside to hide them behind the nodes.
    d3.selectAll(".wedge").lower();


    /*********************************** Functions area ******************************/

    // This function returns midpoint of wedge by considering its side
    function get_wedge_midpoint(x1, x2, y1, y2, i, side) {
        var k, h, l, p1, p2, p3, p4, q1, q2, q3, q4, c1, c2, d1, d2, z1, z2, px1 = 0,
            px2 = 0,
            py1 = 0,
            py2 = 0,
            m1, m2, angle = Math.PI / 100;
        var points = [];
        m1 = (x2 + x1) / 2;
        m2 = (y2 + y1) / 2;

        if (side == "right") {
            // For right side wedge
            if (i % 2 == 0) {
                // For even numbered wedge
                c1 = (x1 + x2 + 1.73 * (y1 - y2)) / 2; // (y1 + y2 + Sqrt[3] (x2 - x1) )/2
                c2 = (y1 + y2 + 1.73 * (x2 - x1)) / 2 // (y1 + y2 + Sqrt[3] (x2 - x1) )/2
            } else {
                // for odd numbered wedge
                c1 = (x1 + x2 - 1.73 * (y1 - y2)) / 2; // (y1 + y2 + Sqrt[3] (x2 - x1) )/2
                c2 = (y1 + y2 - 1.73 * (x2 - x1)) / 2 // (y1 + y2 + Sqrt[3] (x2 - x1) )/2
            }
        } else {
            // For left side wedge
            if (i % 2 == 0) {
                // For even numbered wedge
                c1 = (x1 + x2 - 1.73 * (y1 - y2)) / 2; // (y1 + y2 + Sqrt[3] (x2 - x1) )/2
                c2 = (y1 + y2 - 1.73 * (x2 - x1)) / 2 // (y1 + y2 + Sqrt[3] (x2 - x1) )/2

            } else {
                // for odd numbered wedge
                c1 = (x1 + x2 + 1.73 * (y1 - y2)) / 2; // (y1 + y2 + Sqrt[3] (x2 - x1) )/2
                c2 = (y1 + y2 + 1.73 * (x2 - x1)) / 2 // (y1 + y2 + Sqrt[3] (x2 - x1) )/2
            }
        }

        d1 = (c1 + m1) / 2;
        d2 = (c2 + m2) / 2;

        z1 = (d1 + m1) / 2;
        z2 = (d2 + m2) / 2;

        points[0] = z1;
        points[1] = z2;

        return points;

    }


    }

    ngOnInit() {
        this.visual.onResize = () => {
        };
    }

    ngOnDestroy() {
        d3.select(this.visualContainer.nativeElement).remove();
    }


    onEditNode() {
        document
            .querySelector("#menu")
            .setAttribute('style', 'display:none');

        //this.sidebarService.open(ConfigureNodeComponent);
    }



    //let instance360View = (uri) => this.openInstance360View(uri);
}


//} // End of Component
