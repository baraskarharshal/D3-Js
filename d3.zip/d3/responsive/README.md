This [treemap](https://en.wikipedia.org/wiki/Treemapping) shows the salaries of the Opening Day rosters of the 2017 Houston Astros and Los Angeles Dodgers baseball teams, according to [Cot's Baseball Contracts](http://legacy.baseballprospectus.com/compensation/cots/).

The code uses d3 version 3. Open the preview above in a new window to test responsiveness. This code was developed by Ben Welsh and Ryan Menezes of the Los Angeles Times for the Dec. 14, 2017 story ["Why Wall Street gets a cut of your power bill."](http://www.latimes.com/projects/la-fi-electricity-capacity-investments/).
