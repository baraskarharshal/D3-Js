import { Component, OnInit, ViewChild, ElementRef, AfterViewInit, OnDestroy } from '@angular/core';
//import { VisualComponent } from '../visual.component';
//import { VisualTree } from '../../../../../shared/interfaces/visual-tree.interface';
//import { SidebarService } from '../../../../../shared/components/sidebar/sidebar.service';

//import { Store, Actions, ofActionSuccessful } from '@ngxs/store';
//import { Load360Entity, Load360EntitySuccess, ExplodeEntity } from '../../../state/visual/visual.actions';

import { NodeIcons } from './../icons.config';
//import { CreateDashboard, AddVisual } from '../../../state/dashboard/dashboard.actions';
//import { Dashboard, DashboardType } from '../../../../../shared/interfaces/dashboard.interface';
//import { VisualType } from '../../../../../shared/interfaces/visual.enum';
//import { Visual } from '../../../../../shared/interfaces/visual.interface';
import { withLatestFrom } from 'rxjs/operators';
//import { ApiService } from '../../../../../shared/services/api.service';

declare var d3: any;

@Component({
    selector: 'app-visual-tree',
    templateUrl: './visual-tree.component.html',
    styleUrls: ['./visual-tree.component.css']
})
export class VisualTreeComponent implements OnInit, AfterViewInit, OnDestroy {

    /*
        * Here  base class has 'visual' property will be the object 
        * of 'VisualTree' .. see how we have extend the Visual Component
        */

    @ViewChild('visualContainer')
    visualContainer: ElementRef;
    visual: any = { id: "1234567890" };
    node: any;
    link:any;
    wedges:any;
    simulation: any;

    constructor() {
        this.visual = {
            id: "1234567890",
            isLoading: true,
            config: {
                instance: "test",
                entity: "test2"
            },
            data: [{ "uuid": { "uri": "http://data.latize.com/vocab/component", "id": null }, "label": "has component", "from": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Policy/104764905", "id": null } }, "to": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Component/XL2-XLP2", "id": null }, "label": "Lifelong (XLP2)", "type": { "uri": "http://data.latize.com/vocab/Component", "id": null } } }, { "uuid": { "uri": "http://data.latize.com/vocab/billingFrequency", "id": null }, "label": "billing frequency is", "from": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Policy/104764905", "id": null } }, "to": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/BillingFrequency/1", "id": null }, "label": "ANNUALLY", "type": { "uri": "http://data.latize.com/vocab/BillingFrequency", "id": null } } }, { "uuid": { "uri": "http://data.latize.com/vocab/servicingAgent", "id": null }, "label": "is serviced by", "from": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Policy/104764905", "id": null } }, "to": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Agent/FC1955", "id": null }, "label": "FC1955", "type": { "uri": "http://data.latize.com/vocab/Agent", "id": null } } }, { "uuid": { "uri": "http://data.latize.com/vocab/hasPaymentMethod", "id": null }, "label": "has payment method", "from": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Policy/104764905", "id": null } }, "to": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/PaymentMethod/Creditcard", "id": null }, "label": "Creditcard", "type": { "uri": "http://data.latize.com/vocab/PaymentMethod", "id": null } } }, { "uuid": { "uri": "http://data.latize.com/vocab/policyHolder", "id": null }, "label": "policy holder is", "from": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Policy/104764905", "id": null } }, "to": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Customer/1050053475", "id": null }, "label": "Mr. Adisson Bains", "type": { "uri": "http://data.latize.com/vocab/Customer", "id": null } } }, { "uuid": { "uri": "http://data.latize.com/vocab/statusUpdate", "id": null }, "label": "with status", "from": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Policy/104764905", "id": null } }, "to": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Status/Inforce-19860303", "id": null }, "label": "Inforce ", "type": { "uri": "http://data.latize.com/vocab/Status", "id": null } } }, { "uuid": { "uri": "http://data.latize.com/vocab/billingFrequencyINV", "id": null }, "label": "for policy", "from": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/BillingFrequency/1", "id": null }, "label": "ANNUALLY", "type": { "uri": "http://data.latize.com/vocab/BillingFrequency", "id": null } }, "to": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Policy/104764905", "id": null } } }, { "uuid": { "uri": "http://data.latize.com/vocab/componentForPolicy", "id": null }, "label": "added to policy", "from": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Component/XL2-XLP2", "id": null }, "label": "Lifelong (XLP2)", "type": { "uri": "http://data.latize.com/vocab/Component", "id": null } }, "to": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Policy/104764905", "id": null } } }, { "uuid": { "uri": "http://data.latize.com/vocab/ownsPolicies", "id": null }, "label": "Owns Policy", "from": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Customer/1050053475", "id": null }, "label": "Mr. Adisson Bains", "type": { "uri": "http://data.latize.com/vocab/Customer", "id": null } }, "to": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Policy/104764905", "id": null } } }, { "uuid": { "uri": "http://data.latize.com/vocab/paymentMethodForPolicy", "id": null }, "label": "is payment method for policy", "from": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/PaymentMethod/Creditcard", "id": null }, "label": "Creditcard", "type": { "uri": "http://data.latize.com/vocab/PaymentMethod", "id": null } }, "to": { "@type": "OBJECT", "uuid": { "uri": "http://data.latize.com/resource/Policy/104764905", "id": null } } }]
        }
    }

    ngAfterViewInit() {

        this.render();
    }

    ngOnInit() {
        this.visual.onResize = () => {
        };
    }

    ngOnDestroy() {
        d3.select(this.visualContainer.nativeElement).remove();
    }

    private render() {

        if (this.visual.data && this.visualContainer.nativeElement.offsetWidth > 0) {
            this.visual.isLoading = false;

            this.visual.data.forEach(ins => {
                if (!ins.to.uuid) {
                    ins.to.uuid = ins.uuid
                    console.log("------------------");
                    console.log(ins.to.label);
                    console.log(ins.to.uuid.uri);
                    console.log("------------------");
                }

                if (!ins.from.uuid) {
                    ins.from.uuid = ins.uuid;
                    console.log("------------------");
                    console.log(ins.from.label);
                    console.log(ins.from.uuid.uri);
                    console.log("------------------");
                }
            });
            let dataFormated = this.buildGraph(this.visual.data);
            this.updateGraph(dataFormated);
        }
    }

    onEditNode() {
        document
            .querySelector("#menu")
            .setAttribute('style', 'display:none');

        //this.sidebarService.open(ConfigureNodeComponent);
    }


    private buildGraph(data) {
        let width = this.visualContainer.nativeElement.offsetWidth, //650,//window.innerWidth,
            height = this.visualContainer.nativeElement.offsetHeight, //550,//window.innerHeight,
            root, nodes, dataFormated, clickedParentId, xClick, yClick, clickedNode;
        let centreNodeLabel = this.visual.config.instance;
        //let className = this.visual.config.entity;
        //     let width = document.getElementById('graphID').offsetWidth,
        //     height = document.getElementById('graphID').offsetHeight,
        //     root, nodes, dataFormated, clickedParentId, xClick, yClick, clickedNode;
        // let centreNodeLabel = "TEST", className = "Anudds";
        let min_zoom = 0.1;
        let max_zoom = 7;
        let parentNodeId;
        let uriData;
        //let iconList;
        let firstLoading = true;
        //let imageMap = NodeIcons;
        let ele = this.visualContainer.nativeElement;


        // if (Object.keys(imageMap).indexOf(className) > -1) {
        //     iconList = imageMap[className]
        // } else {
        //     iconList = imageMap['default']
        // }

        d3.selectAll('#explode-' + this.visual.id)
            .on('click', () => {

                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");
                //explode(uriData)
            });

        d3.selectAll('#explore-' + this.visual.id)
            .on('click', () => {

                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");

            });


        d3.selectAll('#explodeList-' + this.visual.id)
            .on('click', () => {

                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");
                //explodeInList(uriData)
            })
        d3.selectAll('#view360-' + this.visual.id)
            .on('click', () => {
                //instance360View(uriData)
                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");
            })

        d3.selectAll('#recommend-' + this.visual.id)
            .on('click', () => {
                // this.recommendCluster(uriData)
                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");
            })
        let selectedNode;

        let tooltip = d3.select("#menu-" + this.visual.id);

        let tooltipInstance = d3.select("#menuInstance-" + this.visual.id);

        let svg = d3.selectAll("#graphID-" + this.visual.id).append("svg")
            .attr("width", width)
            .attr("height", height);


        svg.append("svg:defs").selectAll("marker")
            .data(["end"])// Different link/path types can be defined here
            .enter().append("svg:marker")// This section adds in the arrows
            .attr("id", String)
            .attr("viewBox", "0 -5 10 10")
            .attr("refX", 35)
            .attr("refY", 0)
            .attr("markerWidth", 15)
            .attr("markerHeight", 15)
            .attr("orient", "auto")
            .attr('stroke', '#d9d9d9')
            .attr('fill', 'none')
            .append("svg:path")
            .attr("d", "M0,-5L10,0L0,5");
        let gMaster = svg.append("g")
            .attr("class", "gMaster");
        let gParent = gMaster.append("g")
            .attr("class", "everythingParent");
        let g = gParent.append("g")
            .attr("class", "everything");
        g.append('rect')
            .attr('class', 'bg')
            .attr('x', 0)
            .attr('y', 0)
            .attr('width', width)
            .attr('height', height)
            .attr('fill', '#fff')
            .on('click', () => {
                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");
                d3.selectAll('.clickBox')
                    .attr('opacity', 0)
            })


        this.simulation = d3.forceSimulation()
            .force("link", d3.forceLink().id(d => d.id).distance(150))
            .force("forceX", d3.forceX().strength(0.2).x(width * .5))
            .force("forceY", d3.forceY().strength(0.2).y(height * .5))
            .force("center", d3.forceCenter(width / 2, height / 2))
            .force("charge", d3.forceManyBody().strength(-2000));


        this.link = g.append('g').selectAll(".link");
        this.wedges = g.append('g').selectAll(".wedges");
        this.node = g.append('g').selectAll(".node");
        let generateRandomID = function () {
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            });
        }
        // d3.json('data.json', (error, data) => {

        parentNodeId = data[0].to.uuid.id
        let parent = data[0].to
        data.forEach((el) => {
            let textTemp = el.uuid.uri
            el.uuid.id = textTemp.replace(/[^a - z]/gi, '')

            if (!el.to.uuid) {
                el.to.uuid = { uri: "", id: '' };
            }
            else {
                textTemp = el.to.uuid.uri
                el.to.uuid.id = textTemp.replace(/[^a - z]/gi, '')
            }

            if (!el.from.uuid) {
                el.from.uuid = { uri: "", id: '' };
            } else {
                textTemp = el.from.uuid.uri
                el.from.uuid.id = textTemp.replace(/[^a - z]/gi, '')
            }

        })
        if (data.length > 1) {
            let id1 = data[0].to.uuid.id, id2 = data[1].to.uuid.id, id3 = data[0].from.uuid.id, id4 = data[1].from.uuid.id;
            if ((id1 == id2) || (id1 == id4)) {
                parentNodeId = data[0].to.uuid.id
                parent = data[0].to
            } else {
                parentNodeId = data[0].from.uuid.id
                parent = data[0].from
            }
        }
        console.log(data.length)
        data.forEach((el) => {

            let eq = parentNodeId == el.to.uuid.id;
            if (eq) {
                el.to.label = centreNodeLabel
                el.to.nodeType = 'class'
            } else {
                el.from.label = centreNodeLabel
                el.from.nodeType = 'class'
            }

        })
        console.log(data)
        var nested_data = d3.nest()
            .key(function (d) { return d.label; })
            .entries(data);

        let dataNew = [];
        nested_data.forEach((el) => {
            if (el.values.length === 1) {
                let eq = parentNodeId == el.values[0].to.uuid.id;
                if (eq) {
                    el.values[0].from.uuid.id = generateRandomID()
                    el.values[0].from.nodeType = 'instance'
                } else {
                    el.values[0].to.uuid.id = generateRandomID()
                    el.values[0].to.nodeType = 'instance'
                }
                dataNew.push(el.values[0])
            }
            else {

                let eq = parentNodeId == el.values[0].to.uuid.id;
                if (eq)
                    dataNew.push({
                        "uuid": {
                            "uri": "",
                            "id": null
                        },
                        "label": el.key,
                        "from": {
                            "@type": "ui_cluster",
                            "nodeType": 'cluster',
                            "uuid": {
                                "uri": el.key.replace(/\s +/, ""),
                                "id": el.key.replace(/\s +/, "")
                            },
                            "label": el.key,
                            "type": null
                        },
                        "to": parent
                    })
                else
                    dataNew.push({
                        "uuid": {
                            "uri": "",
                            "id": null
                        },
                        "label": el.key,
                        "to": {
                            "@type": "ui_cluster",
                            "nodeType": 'cluster',
                            "uuid": {
                                "uri": el.key.replace(/\s +/, ""),
                                "id": el.key.replace(/\s +/, "")
                            },
                            "label": el.key,
                            "type": null
                        },
                        "from": parent
                    })
                el.values.forEach((element) => {
                    let eq = parentNodeId == element.to.uuid.id;
                    if (!eq) {
                        if (element.to.uuid) {
                            dataNew.push({
                                "uuid": element.uuid,
                                "label": element.label,
                                "from": {
                                    "@type": "ui_cluster",
                                    "nodeType": 'cluster',
                                    "uuid": {
                                        "uri": el.key.replace(/\s +/, ""),
                                        "id": el.key.replace(/\s +/, "")
                                    },
                                    "label": el.key,
                                    "type": null
                                },
                                "to": {
                                    "@type": element.to['@type'],
                                    "nodeType": 'instance',
                                    "uuid": {
                                        "uri": element.to.uuid.uri,
                                        "id": generateRandomID()
                                    },
                                    "label": element.to.label,
                                    "type": element.to.type
                                }
                            })
                        }
                    }
                    else {
                        if (element.from.uuid) {
                            dataNew.push({
                                "uuid": element.uuid,
                                "label": element.label,
                                "to": {
                                    "@type": "ui_cluster",
                                    "nodeType": 'cluster',
                                    "uuid": {
                                        "uri": el.key.replace(/\s +/, ""),
                                        "id": el.key.replace(/\s +/, "")
                                    },
                                    "label": el.key,
                                    "type": null
                                },
                                "from": {
                                    "@type": element.from['@type'],
                                    "nodeType": 'instance',

                                    "uuid": {
                                        "uri": element.from.uuid.uri,
                                        "id": generateRandomID()
                                    },
                                    "label": element.from.label,
                                    "type": element.from.type
                                }
                            })
                        }
                    }
                })
            }
        })
        
        console.log(dataNew)

        root = dataNew
        dataFormated = dataFormating(dataNew)
        console.log(dataFormated)
        
        // })
        

        function dataFormating(data) {
            let nodes = [], links = [], uriList = [];
            data.forEach(function (element) {
                if (!uriList.includes(element.from.uuid.id)) {
                    uriList.push(element.from.uuid.id)
                    nodes.push(element.from)
                    nodes[nodes.length - 1]['id'] = element.from.uuid.id
                }
                if (!uriList.includes(element.to.uuid.id)) {
                    uriList.push(element.to.uuid.id)
                    nodes.push(element.to)
                    nodes[nodes.length - 1]['id'] = element.to.uuid.id
                }
                links.push(element)
                links[links.length - 1].source = element.from.uuid.id
                links[links.length - 1].target = element.to.uuid.id

            });
            let k = 0;
            let graphData = {};
            graphData['nodes'] = nodes;
            graphData['links'] = links;
            graphData['hiddenNodes'] = [];
            return graphData
        }



        

        

        



        //Function for resize


        let zoomOnWindowResize = () => {
            console.log("d3.event.transform")
            let tempWidth = document.getElementById("graphID-" + this.visual.id).offsetWidth;
            let tempHeight = document.getElementById("graphID-" + this.visual.id).offsetHeight;
            let scaleFactor = tempWidth / width
            g.attr("transform", `scale($ {scaleFactor})translate($ {(tempWidth - width)/2}, $ {(tempHeight - height)/2})`)

            svg.attr("width", tempWidth)
                .attr("height", tempHeight);
        }
        this.visual.onResize = zoomOnWindowResize;

        //add zoom capabilities 
        let zoom_handler = d3.zoom()
            .on("zoom", zoom_actions);
        window.addEventListener('resize', zoomOnWindowResize);
        zoom_handler(svg);
        function zoom_actions() {
            g.attr("transform", d3.event.transform)
        }
        //Function on explode

        return dataFormated;
    } // end of function buildGraph

    //Function on explore

    private updateGraph(dataFormated) {

        let iconList;
        let imageMap = NodeIcons;
        let className = this.visual.config.entity;

        if (Object.keys(imageMap).indexOf(className) > -1) {
            iconList = imageMap[className]
        } else {
            iconList = imageMap['default']
        }

        this.node = this.node.data(dataFormated.nodes, function (d) { return d.id; });
        this.node.exit().remove();
        console.log(dataFormated.links)
        // Apply the general update pattern to the links.
        this.link = this.link.data(dataFormated.links, function (d) { return d.source.id + "-" + d.target.id; });
        this.wedges = this.wedges.data(dataFormated.links, function (d) { return d.source.id + "-" + d.target.id; });
        this.link.exit().remove();
        this.wedges.exit().remove();
        this.link = this.link.enter()
            .append("line")
            .attr("stroke-width", 1)
            .attr('stroke', '#d9d9d9')
            .merge(this.link).attr("marker-end", "url(#end)");

            this.wedges = this.wedges.enter()
            .append("path")
            .attr('fill', '#d9d9d9')
            .merge(this.wedges)

            this.node = this.node.enter()
            .append("g")
            .attr("class", 'nodes')
            .on("click", click)
            .on('contextmenu', (d, i) => {
                // d3.event.preventDefault();
                function getOffset(el) {
                    const rect = el.getBoundingClientRect();
                    return {
                        left: rect.left + window.scrollX,
                        top: rect.top + window.scrollY
                    };
                }

                const x = d3.event.pageX - getOffset(ele).left;
                const y = d3.event.pageY - getOffset(ele).top;
                //d3.mouse(d)[1];

                if ((d['@type'] != 'CLUSTER') && (d['@type'] != 'ULCluster')) {

                    uriData = d;
                    clickedNode = d
                    console.log(d)
                    tooltipInstance.style("display", "inline");
                    tooltipInstance.style("top", (y - 10) + "px").style("left", (x + 10) + "px");
                }
                else {

                    uriData = d;
                    tooltip.style("display", "inline");
                    tooltip.style("top", (y - 10) + "px").style("left", (x + 10) + "px");
                    xClick = x;
                    yClick = y;
                    clickedNode = d
                    console.log(d)
                }
            })
            .merge(this.node)
            .call(d3.drag()
                .on("start", dragstarted)
                .on("drag", dragged)
                .on("end", dragended));

        let dimensions = (d, i) => {
            if (d['@type'] === 'ULCluster' || d['@type'] === 'CLUSTER') {
                return 65;
            }
            else if (d['@type'] === 'instance' || d['@type'] === 'OBJECT') {
                return 45;
            }
            else
                return 55;
        };

        this.node.append("image")
            .attr("xlink:href", (d, i) => {

                if (d['@type'] === 'ULCluster' || d['@type'] === 'CLUSTER') {
                    return iconList['cluster']
                }
                if (!iconList[d.nodeType]) {
                    console.log("node not found for" + d.nodeType);
                    return iconList['default']
                }
                console.log("________________" + iconList[d.nodeType]);
                return iconList[d.nodeType]
            })
            .attr("width", (d, i) => dimensions(d, i))
            .attr("height", (d, i) => dimensions(d, i))
            .attr("x", -55 / 2)
            .attr("y", -55 / 2)
            .attr('fill', '#000')

        console.log(iconList)

        this.node.append("image")
            .attr('class', (d) => "clickBox id" + d.uuid.id)
            .attr("xlink:href", "/assets/svg/mouseClick.svg")
            .attr("width", (d, i) => dimensions(d, i))
            .attr("height", (d, i) => dimensions(d, i))
            .attr("x", -55 / 2)
            .attr("y", -55 / 2)
            .attr('opacity', 0)

            this.node.append('text')
            .text(d => {

                if (d['@type'] === "ULCluster" || d['@type'] === 'CLUSTER') {
                    return d.label + ' - ' + d.count;
                }
                return d.label;
            })
            .attr('text-anchor', 'middle')
            .attr('x', 0)
            .attr('y', d => {
                if (d['@type'] === "ULCluster" || d['@type'] === 'CLUSTER' || d['@type'] === "ui_cluster") {
                    return 50
                }

                return 40;
            })


            this.node.append("title")
            .text((d) => d.id);

            function click(d) {
                tooltip.style("display", "none");
                tooltipInstance.style("display", "none");
                d3.selectAll('.clickBox')
                    .attr('opacity', 0)
                d3.selectAll(".id"+d.uuid.id)
                    .attr('opacity', 1);
            }

            function dragstarted(d) {
                if (!d3.event.active) this.simulation.alphaTarget(0.3).restart();
                d.fx = d.x;
                d.fy = d.y;
            }
    
            function dragged(d) {
                d.fx = d3.event.x;
                d.fy = d3.event.y;
            }
    
            function dragended(d) {
                if (!d3.event.active) this.simulation.alphaTarget(0);
                d.fx = null;
                d.fy = null;
            }

            function scaling() {
                firstLoading = false;
            }
            
    

        this.simulation
            .nodes(dataFormated.nodes)
            .on("tick", ticked)
            .on('end', scaling);

        this.simulation.force("link")
            .links(dataFormated.links);
        this.simulation.alpha(0.1).restart();

        function ticked() {
            this.link
                .attr("x1", (d) => d.source.x)
                .attr("y1", (d) => d.source.y)
                .attr("x2", (d) => d.target.x)
                .attr("y2", (d) => d.target.y)
                .attr('opacity', (d) => {
                    if (d.linkType == 'wedges')
                        return 0
                    if ((d.source.nodeType == 'instance') || (d.target.nodeType == 'instance')) {
                        if ((d.source['@type'] == 'CLUSTER') || (d.target['@type'] == 'CLUSTER')) {
                            return 1
                        }
                        return 0
                    }
                    return 1
                });
    
                this.wedges.attr('d', (d) => {
                let k, h, l, x1, x2, y1, y2, angle = Math.PI / 100;
                l = Math.sqrt((d.source.x - d.target.x) * (d.source.x - d.target.x) + (d.source.y - d.target.y) * (d.source.y - d.target.y))
                let dy = (d.target.y - d.source.y);
                let dx = (- d.target.x + d.source.x);
                k = dy * Math.tan(angle)
                h = dx * Math.tan(angle)
                x1 = d.source.x + k
                x2 = d.source.x - k
                y1 = d.source.y + h
                y2 = d.source.y - h
                return 'M ' + d.target.x + ' ' + d.target.y + ' L ' + x1 + ' ' + y1 + ' L ' + x2 + ' ' + y2 + ' z';
            })
                .attr('opacity', (d) => {
                    if (d.linkType == 'wedges')
                        return 1
                    if ((d.source.nodeType == 'instance') || (d.target.nodeType == 'instance')) {
    
                        if ((d.source['@type'] == 'CLUSTER') || (d.target['@type'] == 'CLUSTER')) {
                            return 0
                        }
                        return 1
                    }
                    return 0
                });
    
                this.node
                .attr("transform", (d) => "translate(" + d.x + "," + d.y + ")")
                .attr('style', (d) => "transform:matrix(1, 0, 0, 1, " + d.x + "," + d.y + "); ");
    
            if (firstLoading) {
    
                let boundingBoxX = d3.max(dataFormated.nodes, function (d) { return d.x; }) - d3.min(dataFormated.nodes, function (d) { return d.x; }),
                    boundingBoxy = d3.max(dataFormated.nodes, function (d) { return d.y; }) - d3.min(dataFormated.nodes, function (d) { return d.y; })
    
                let scaleFc
                if (width / boundingBoxX < height / boundingBoxy) {
                    scaleFc = (width - 55) / boundingBoxX
                } else {
                    scaleFc = (height - 55) / boundingBoxy
    
                }
                if (scaleFc < 1)
                    // gMaster.attr("transform", `scale(${scaleFc}) translate(${(width) / 2}, ${(height) / 2})`)
                    gMaster.attr("transform", `scale($ {scaleFc})translate($ {55}, $ {55})`)
            }
            /*            
                    node
                        .attr("transform", function (d) {
                            d.x = Math.max(27.5, Math.min(width - 27.5, d.x))
                            d.y = Math.max(27.5, Math.min(height - 27.5, d.y))
                            return `translate(${d.x},${d.y};`
                        })
                        .attr('style', (d) => `transform: matrix(1, 0, 0, 1, ${d.x},${d.y});`);
                    */
        }

    }

    

}


//} // End of Component
