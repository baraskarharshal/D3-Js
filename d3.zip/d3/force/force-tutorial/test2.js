{"nodes":[
    {"@type":"ui_cluster","nodeType":"cluster","uuid":{"uri":"is a","id":"is a"},"label":"is a","type":null,"id":"is a"},

    {"@type":"CLUSTER","entityType":{"uri":"http://data.latize.com/vocab/69353fc6a5350a0bdfe9bce1a946251dcd8453dd","id":null},"count":0,"label":"test","uuid":{"uri":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type","id":"a"},"nodeType":"class","id":"a"}
    
    ,{"@type":"OBJECT","nodeType":"instance","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"dd8c1044-f154-4df3-9bad-be0f58c1931e"},"id":"dd8c1044-f154-4df3-9bad-be0f58c1931e"},
    
    {"@type":"OBJECT","nodeType":"instance","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"f2b65cfe-392d-47ae-bb0d-4bbd344f56dd"},"id":"f2b65cfe-392d-47ae-bb0d-4bbd344f56dd"},
    
    {"@type":"OBJECT","nodeType":"instance","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"fc0899c2-355c-435a-b8f6-a01fe5667963"},"id":"fc0899c2-355c-435a-b8f6-a01fe5667963"},
    
    {"@type":"OBJECT","nodeType":"instance","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"ef131bc3-dea4-4426-b6df-23bb5b7a0c15"},"id":"ef131bc3-dea4-4426-b6df-23bb5b7a0c15"},
    
    {"@type":"OBJECT","nodeType":"instance","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"2afa28ab-1996-49de-a334-8d9cfea1819e"},"id":"2afa28ab-1996-49de-a334-8d9cfea1819e"},
    
    {"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"aaazA"},"label":"test","nodeType":"class","id":"aaazA"},
    
    {"@type":"STRING","value":"HOUS","uuid":{"uri":"http://data.latize.com/vocab/occupation","id":"aa04f0d3-d210-46e1-a01a-6b86b815fe41"},"nodeType":"instance","id":"aa04f0d3-d210-46e1-a01a-6b86b815fe41"},
    
    {"@type":"INTEGER","value":85,"uuid":{"uri":"http://data.latize.com/vocab/age","id":"306a140b-ab63-434e-acb2-c103bfeb11a6"},"nodeType":"instance","id":"306a140b-ab63-434e-acb2-c103bfeb11a6"},
    
    {"@type":"STRING","value":"A10007685","uuid":{"uri":"http://www.w3.org/2000/01/rdf-schema#label","id":"6fe5485c-e162-4592-9ed6-41b93133624b"},"nodeType":"instance","id":"6fe5485c-e162-4592-9ed6-41b93133624b"},
    
    {"@type":"DOUBLE","value":4388,"uuid":{"uri":"http://data.latize.com/vocab/estimatedIncome","id":"64b38398-c283-4750-bec7-bcdedb452cb0"},"nodeType":"instance","id":"64b38398-c283-4750-bec7-bcdedb452cb0"},
    
    {"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Singapore","id":"04f1b7fd-032a-4fb9-8487-8ccaaca93660"},"label":"Singapore","type":{"uri":"http://www.w3.org/2002/07/owl#NamedIndividual","id":null},"nodeType":"instance","id":"04f1b7fd-032a-4fb9-8487-8ccaaca93660"},
    
    {"@type":"INTEGER","value":1,"uuid":{"uri":"http://data.latize.com/vocab/noifp","id":"fbeb6c1c-cd52-4e32-9f1f-ce138ff9a9d1"},"nodeType":"instance","id":"fbeb6c1c-cd52-4e32-9f1f-ce138ff9a9d1"},
    
    {"@type":"DATE","value":"1932-05-17T00:00:00.000Z","format":"yyyy-MM-dd","uuid":{"uri":"http://data.latize.com/vocab/dateOfBirth","id":"3712b51d-dd2e-4c57-b324-863bf9267fa2"},"nodeType":"instance","id":"3712b51d-dd2e-4c57-b324-863bf9267fa2"},
    
    {"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Policy/15115980","id":"74c08186-70cc-462c-8976-867111d511fb"},"label":"15115980","type":{"uri":"http://data.latize.com/vocab/bb9cf1418089b3356038fdd24fcbdc9d1a7c42a5","id":null},"nodeType":"instance","id":"74c08186-70cc-462c-8976-867111d511fb"},
    
    {"@type":"STRING","value":"1050088725","uuid":{"uri":"http://data.latize.com/vocab/customerID","id":"b33b21d1-868b-4bb1-95e9-64dbaf3560eb"},"nodeType":"instance","id":"b33b21d1-868b-4bb1-95e9-64dbaf3560eb"}],
    
    "links":[
        {"uuid":{"uri":"","id":null},"label":"is a","from":{"@type":"ui_cluster","nodeType":"cluster","uuid":{"uri":"is a","id":"is a"},"label":"is a","type":null,"id":"is a"},"to":{"@type":"CLUSTER","entityType":{"uri":"http://data.latize.com/vocab/69353fc6a5350a0bdfe9bce1a946251dcd8453dd","id":null},"count":0,"label":"test","uuid":{"uri":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type","id":"a"},"nodeType":"class","id":"a"},"source":"is a","target":"a"},
        
        {"uuid":{"uri":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type","id":"a"},"label":"is a","to":{"@type":"ui_cluster","nodeType":"cluster","uuid":{"uri":"is a","id":"is a"},"label":"is a","type":null},"from":{"@type":"OBJECT","nodeType":"instance","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"dd8c1044-f154-4df3-9bad-be0f58c1931e"},"id":"dd8c1044-f154-4df3-9bad-be0f58c1931e"},"source":"dd8c1044-f154-4df3-9bad-be0f58c1931e","target":"is a"},
        
        {"uuid":{"uri":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type","id":"a"},"label":"is a","to":{"@type":"ui_cluster","nodeType":"cluster","uuid":{"uri":"is a","id":"is a"},"label":"is a","type":null},"from":{"@type":"OBJECT","nodeType":"instance","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"f2b65cfe-392d-47ae-bb0d-4bbd344f56dd"},"id":"f2b65cfe-392d-47ae-bb0d-4bbd344f56dd"},"source":"f2b65cfe-392d-47ae-bb0d-4bbd344f56dd","target":"is a"},
        
        {"uuid":{"uri":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type","id":"a"},"label":"is a","to":{"@type":"ui_cluster","nodeType":"cluster","uuid":{"uri":"is a","id":"is a"},"label":"is a","type":null},"from":{"@type":"OBJECT","nodeType":"instance","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"fc0899c2-355c-435a-b8f6-a01fe5667963"},"id":"fc0899c2-355c-435a-b8f6-a01fe5667963"},"source":"fc0899c2-355c-435a-b8f6-a01fe5667963","target":"is a"},
        
        {"uuid":{"uri":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type","id":"a"},"label":"is a","to":{"@type":"ui_cluster","nodeType":"cluster","uuid":{"uri":"is a","id":"is a"},"label":"is a","type":null},"from":{"@type":"OBJECT","nodeType":"instance","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"ef131bc3-dea4-4426-b6df-23bb5b7a0c15"},"id":"ef131bc3-dea4-4426-b6df-23bb5b7a0c15"},"source":"ef131bc3-dea4-4426-b6df-23bb5b7a0c15","target":"is a"},
        
        {"uuid":{"uri":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type","id":"a"},"label":"is a","to":{"@type":"ui_cluster","nodeType":"cluster","uuid":{"uri":"is a","id":"is a"},"label":"is a","type":null},"from":{"@type":"OBJECT","nodeType":"instance","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"2afa28ab-1996-49de-a334-8d9cfea1819e"},"id":"2afa28ab-1996-49de-a334-8d9cfea1819e"},"source":"2afa28ab-1996-49de-a334-8d9cfea1819e","target":"is a"},
        
        {"uuid":{"uri":"http://data.latize.com/vocab/occupation","id":"aa04f0d3-d210-46e1-a01a-6b86b815fe41"},"label":"occupation is","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"aaazA"},"label":"test","nodeType":"class","id":"aaazA"},"to":{"@type":"STRING","value":"HOUS","uuid":{"uri":"http://data.latize.com/vocab/occupation","id":"aa04f0d3-d210-46e1-a01a-6b86b815fe41"},"nodeType":"instance","id":"aa04f0d3-d210-46e1-a01a-6b86b815fe41"},"source":"aaazA","target":"aa04f0d3-d210-46e1-a01a-6b86b815fe41"},
        
        {"uuid":{"uri":"http://data.latize.com/vocab/age","id":"306a140b-ab63-434e-acb2-c103bfeb11a6"},"label":"age is","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"aaazA"},"label":"test","nodeType":"class"},"to":{"@type":"INTEGER","value":85,"uuid":{"uri":"http://data.latize.com/vocab/age","id":"306a140b-ab63-434e-acb2-c103bfeb11a6"},"nodeType":"instance","id":"306a140b-ab63-434e-acb2-c103bfeb11a6"},"source":"aaazA","target":"306a140b-ab63-434e-acb2-c103bfeb11a6"},
        
        {"uuid":{"uri":"http://www.w3.org/2000/01/rdf-schema#label","id":"6fe5485c-e162-4592-9ed6-41b93133624b"},"label":"has label","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"aaazA"},"label":"test","nodeType":"class"},"to":{"@type":"STRING","value":"A10007685","uuid":{"uri":"http://www.w3.org/2000/01/rdf-schema#label","id":"6fe5485c-e162-4592-9ed6-41b93133624b"},"nodeType":"instance","id":"6fe5485c-e162-4592-9ed6-41b93133624b"},"source":"aaazA","target":"6fe5485c-e162-4592-9ed6-41b93133624b"},
        
        {"uuid":{"uri":"http://data.latize.com/vocab/estimatedIncome","id":"64b38398-c283-4750-bec7-bcdedb452cb0"},"label":"estimated income is","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"aaazA"},"label":"test","nodeType":"class"},"to":{"@type":"DOUBLE","value":4388,"uuid":{"uri":"http://data.latize.com/vocab/estimatedIncome","id":"64b38398-c283-4750-bec7-bcdedb452cb0"},"nodeType":"instance","id":"64b38398-c283-4750-bec7-bcdedb452cb0"},"source":"aaazA","target":"64b38398-c283-4750-bec7-bcdedb452cb0"},
        
        {"uuid":{"uri":"http://data.latize.com/vocab/livesIn","id":"aaaza"},"label":"lives in","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"aaazA"},"label":"test","nodeType":"class"},"to":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Singapore","id":"04f1b7fd-032a-4fb9-8487-8ccaaca93660"},"label":"Singapore","type":{"uri":"http://www.w3.org/2002/07/owl#NamedIndividual","id":null},"nodeType":"instance","id":"04f1b7fd-032a-4fb9-8487-8ccaaca93660"},"source":"aaazA","target":"04f1b7fd-032a-4fb9-8487-8ccaaca93660"},
        
        {"uuid":{"uri":"http://data.latize.com/vocab/noifp","id":"fbeb6c1c-cd52-4e32-9f1f-ce138ff9a9d1"},"label":"no. of policies in-force is","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"aaazA"},"label":"test","nodeType":"class"},"to":{"@type":"INTEGER","value":1,"uuid":{"uri":"http://data.latize.com/vocab/noifp","id":"fbeb6c1c-cd52-4e32-9f1f-ce138ff9a9d1"},"nodeType":"instance","id":"fbeb6c1c-cd52-4e32-9f1f-ce138ff9a9d1"},"source":"aaazA","target":"fbeb6c1c-cd52-4e32-9f1f-ce138ff9a9d1"},
        
        {"uuid":{"uri":"http://data.latize.com/vocab/dateOfBirth","id":"3712b51d-dd2e-4c57-b324-863bf9267fa2"},"label":"date of birth is","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"aaazA"},"label":"test","nodeType":"class"},"to":{"@type":"DATE","value":"1932-05-17T00:00:00.000Z","format":"yyyy-MM-dd","uuid":{"uri":"http://data.latize.com/vocab/dateOfBirth","id":"3712b51d-dd2e-4c57-b324-863bf9267fa2"},"nodeType":"instance","id":"3712b51d-dd2e-4c57-b324-863bf9267fa2"},"source":"aaazA","target":"3712b51d-dd2e-4c57-b324-863bf9267fa2"},
        
        {"uuid":{"uri":"http://data.latize.com/vocab/ownsPolicy","id":"aaaza"},"label":"owns policy","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"aaazA"},"label":"test","nodeType":"class"},"to":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Policy/15115980","id":"74c08186-70cc-462c-8976-867111d511fb"},"label":"15115980","type":{"uri":"http://data.latize.com/vocab/bb9cf1418089b3356038fdd24fcbdc9d1a7c42a5","id":null},"nodeType":"instance","id":"74c08186-70cc-462c-8976-867111d511fb"},"source":"aaazA","target":"74c08186-70cc-462c-8976-867111d511fb"},
        
        {"uuid":{"uri":"http://data.latize.com/vocab/customerID","id":"b33b21d1-868b-4bb1-95e9-64dbaf3560eb"},"label":"customer id is","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":"aaazA"},"label":"test","nodeType":"class"},"to":{"@type":"STRING","value":"1050088725","uuid":{"uri":"http://data.latize.com/vocab/customerID","id":"b33b21d1-868b-4bb1-95e9-64dbaf3560eb"},"nodeType":"instance","id":"b33b21d1-868b-4bb1-95e9-64dbaf3560eb"},"source":"aaazA","target":"b33b21d1-868b-4bb1-95e9-64dbaf3560eb"}
    
    ],"hiddenNodes":[]}