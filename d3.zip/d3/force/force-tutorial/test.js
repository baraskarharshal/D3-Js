[{"uuid":{"uri":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type","id":null},"label":"is a"
,"from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":null}}
,"to":{"@type":"CLUSTER","entityType":{"uri":"http://data.latize.com/vocab/69353fc6a5350a0bdfe9bce1a946251dcd8453dd","id":null},"count":0,"label":"Married Person"}},

{"uuid":{"uri":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type","id":null},"label":"is a","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":null}},"to":{"@type":"CLUSTER","entityType":{"uri":"http://data.latize.com/vocab/7f02f5087f9bddbfe9ab83b5174eef25f6b12918","id":null},"count":0,"label":"Existing Customer"}}

,{"uuid":{"uri":"http://data.latize.com/vocab/occupation","id":null},"label":"occupation is","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":null}},"to":{"@type":"STRING","value":"HOUS"}}

,{"uuid":{"uri":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type","id":null},"label":"is a","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":null}},"to":{"@type":"CLUSTER","entityType":{"uri":"http://data.latize.com/vocab/5d8949b19144f3c23ca78100c9b428b078f59521","id":null},"count":0,"label":"Female Person"}}

,{"uuid":{"uri":"http://data.latize.com/vocab/age","id":null},"label":"age is","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":null}},"to":{"@type":"INTEGER","value":85}}

,{"uuid":{"uri":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type","id":null},"label":"is a","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":null}},"to":{"@type":"CLUSTER","entityType":{"uri":"http://data.latize.com/vocab/6573693bd87394c79ac7c125b98ac1769ea5c1a8","id":null},"count":0,"label":"Retiree"}}

,{"uuid":{"uri":"http://www.w3.org/2000/01/rdf-schema#label","id":null},"label":"has label","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":null}},"to":{"@type":"STRING","value":"A10007685"}}

,{"uuid":{"uri":"http://data.latize.com/vocab/estimatedIncome","id":null},"label":"estimated income is","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":null}},"to":{"@type":"DOUBLE","value":4388.0}}

,{"uuid":{"uri":"http://data.latize.com/vocab/livesIn","id":null},"label":"lives in","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":null}},"to":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Singapore","id":null},"label":"Singapore","type":{"uri":"http://www.w3.org/2002/07/owl#NamedIndividual","id":null}}}

,{"uuid":{"uri":"http://data.latize.com/vocab/noifp","id":null},"label":"no. of policies in-force is","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":null}},"to":{"@type":"INTEGER","value":1}}

,{"uuid":{"uri":"http://data.latize.com/vocab/dateOfBirth","id":null},"label":"date of birth is","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":null}},"to":{"@type":"DATE","value":"1932-05-17T00:00:00.000Z","format":"yyyy-MM-dd"}}

,{"uuid":{"uri":"http://www.w3.org/1999/02/22-rdf-syntax-ns#type","id":null},"label":"is a","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":null}},"to":{"@type":"CLUSTER","entityType":{"uri":"http://data.latize.com/vocab/00e5a507c3d4ef71e597bc3dfc0535eccd426c39","id":null},"count":0,"label":"Non PMT professional"}}

,{"uuid":{"uri":"http://data.latize.com/vocab/ownsPolicy","id":null},"label":"owns policy","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":null}},"to":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Policy/15115980","id":null},"label":"15115980","type":{"uri":"http://data.latize.com/vocab/bb9cf1418089b3356038fdd24fcbdc9d1a7c42a5","id":null}}}

,{"uuid":{"uri":"http://data.latize.com/vocab/customerID","id":null},"label":"customer id is","from":{"@type":"OBJECT","uuid":{"uri":"http://data.latize.com/resource/Person/A10007685","id":null}},"to":{"@type":"STRING","value":"1050088725"}}]