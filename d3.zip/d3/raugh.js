data: [{
    "uuid": {
        "uri": "http://data.latize.com/vocab/component",
        "id": null
    },
    "label": "has component",
    "from": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Policy/104764905",
            "id": null
        }
    },
    "to": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Component/XL2-XLP2",
            "id": null
        },
        "label": "Lifelong (XLP2)",
        "type": {
            "uri": "http://data.latize.com/vocab/Component",
            "id": null
        }
    }
}, {
    "uuid": {
        "uri": "http://data.latize.com/vocab/billingFrequency",
        "id": null
    },
    "label": "billing frequency is",
    "from": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Policy/104764905",
            "id": null
        }
    },
    "to": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/BillingFrequency/1",
            "id": null
        },
        "label": "ANNUALLY",
        "type": {
            "uri": "http://data.latize.com/vocab/BillingFrequency",
            "id": null
        }
    }
}, {
    "uuid": {
        "uri": "http://data.latize.com/vocab/servicingAgent",
        "id": null
    },
    "label": "is serviced by",
    "from": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Policy/104764905",
            "id": null
        }
    },
    "to": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Agent/FC1955",
            "id": null
        },
        "label": "FC1955",
        "type": {
            "uri": "http://data.latize.com/vocab/Agent",
            "id": null
        }
    }
}, {
    "uuid": {
        "uri": "http://data.latize.com/vocab/hasPaymentMethod",
        "id": null
    },
    "label": "has payment method",
    "from": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Policy/104764905",
            "id": null
        }
    },
    "to": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/PaymentMethod/Creditcard",
            "id": null
        },
        "label": "Creditcard",
        "type": {
            "uri": "http://data.latize.com/vocab/PaymentMethod",
            "id": null
        }
    }
}, {
    "uuid": {
        "uri": "http://data.latize.com/vocab/policyHolder",
        "id": null
    },
    "label": "policy holder is",
    "from": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Policy/104764905",
            "id": null
        }
    },
    "to": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Customer/1050053475",
            "id": null
        },
        "label": "Mr. Adisson Bains",
        "type": {
            "uri": "http://data.latize.com/vocab/Customer",
            "id": null
        }
    }
}, {
    "uuid": {
        "uri": "http://data.latize.com/vocab/statusUpdate",
        "id": null
    },
    "label": "with status",
    "from": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Policy/104764905",
            "id": null
        }
    },
    "to": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Status/Inforce-19860303",
            "id": null
        },
        "label": "Inforce ",
        "type": {
            "uri": "http://data.latize.com/vocab/Status",
            "id": null
        }
    }
}, {
    "uuid": {
        "uri": "http://data.latize.com/vocab/billingFrequencyINV",
        "id": null
    },
    "label": "for policy",
    "from": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/BillingFrequency/1",
            "id": null
        },
        "label": "ANNUALLY",
        "type": {
            "uri": "http://data.latize.com/vocab/BillingFrequency",
            "id": null
        }
    },
    "to": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Policy/104764905",
            "id": null
        }
    }
}, {
    "uuid": {
        "uri": "http://data.latize.com/vocab/componentForPolicy",
        "id": null
    },
    "label": "added to policy",
    "from": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Component/XL2-XLP2",
            "id": null
        },
        "label": "Lifelong (XLP2)",
        "type": {
            "uri": "http://data.latize.com/vocab/Component",
            "id": null
        }
    },
    "to": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Policy/104764905",
            "id": null
        }
    }
}, {
    "uuid": {
        "uri": "http://data.latize.com/vocab/ownsPolicies",
        "id": null
    },
    "label": "Owns Policy",
    "from": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Customer/1050053475",
            "id": null
        },
        "label": "Mr. Adisson Bains",
        "type": {
            "uri": "http://data.latize.com/vocab/Customer",
            "id": null
        }
    },
    "to": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Policy/104764905",
            "id": null
        }
    }
}, {
    "uuid": {
        "uri": "http://data.latize.com/vocab/paymentMethodForPolicy",
        "id": null
    },
    "label": "is payment method for policy",
    "from": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/PaymentMethod/Creditcard",
            "id": null
        },
        "label": "Creditcard",
        "type": {
            "uri": "http://data.latize.com/vocab/PaymentMethod",
            "id": null
        }
    },
    "to": {
        "@type": "OBJECT",
        "uuid": {
            "uri": "http://data.latize.com/resource/Policy/104764905",
            "id": null
        }
    }
}]